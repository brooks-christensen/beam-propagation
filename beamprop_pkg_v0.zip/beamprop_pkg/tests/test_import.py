def test_import():
    import beamprop
    assert hasattr(beamprop, "__version__")
