import numpy as np

def k0_from_lambda(wavelength):
    """Return free-space wavenumber k0 = 2π/λ."""
    return 2.0 * np.pi / wavelength

def fftfreq_2d(nx, ny, dx, dy):
    """Return angular spatial frequencies (kx, ky) on the FFT grid."""
    kx = 2*np.pi*np.fft.fftfreq(nx, d=dx)
    ky = 2*np.pi*np.fft.fftfreq(ny, d=dy)
    return np.meshgrid(kx, ky, indexing="ij")

def fft2c(u):
    """Centered 2D FFT (unitary norm)."""
    return np.fft.fftshift(np.fft.fft2(np.fft.ifftshift(u), norm="ortho"))

def ifft2c(U):
    """Centered 2D IFFT (unitary norm)."""
    return np.fft.fftshift(np.fft.ifft2(np.fft.ifftshift(U), norm="ortho"))

def fft1c(u):
    """Centered 1D FFT (unitary)."""
    return np.fft.fftshift(np.fft.fft(np.fft.ifftshift(u), norm="ortho"))

def ifft1c(U):
    """Centered 1D IFFT (unitary)."""
    return np.fft.fftshift(np.fft.ifft(np.fft.ifftshift(U), norm="ortho"))
